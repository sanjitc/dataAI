docker cp Hotels3.csv mongo-tutorial:/tmp/
docker cp RentalCar1.csv dv-ifmx-tutorial:/tmp/
docker cp 1_mongo.sh mongo-tutorial:/tmp/
docker cp 1_informix.sh dv-ifmx-tutorial:/tmp/
