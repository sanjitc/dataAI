DROP VIEW TRAVELDATA;
 CREATE VIEW TRAVELDATA
      AS SELECT "USER999"."rentalcar"."model"  CARMODEL, 
                "USER999"."rentalcar"."agency" CARAGENCY, 
                "USER999"."rentalcar"."size"   CARSIZE, 
                "USER999"."rentalcar"."borough" BOROUGH,
                "USER999"."rentalcar"."sizeid" SIZEID, 
                "USER999"."HOTEL"."NAME"       HOTEL,
                "USER999"."HOTEL"."RATING"     HOTELRATING,
                ("USER999"."HOTEL"."PRICE" + "USER999"."rentalcar"."rent") COST 
      FROM "USER999"."rentalcar", "USER999"."HOTEL" 
      WHERE "USER999"."rentalcar"."borough" = "USER999"."HOTEL"."BOROUGH";
