#!/bin/sh

export PAYLOAD=/tmp

#Load hotel data
mongoimport -u mongodbuser -p password -d icpd_mongo -c hotel --type CSV --file $PAYLOAD/Hotels3.csv --headerline
